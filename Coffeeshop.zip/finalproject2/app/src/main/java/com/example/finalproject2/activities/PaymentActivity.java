package com.example.finalproject2.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.finalproject2.MainActivity;
import com.example.finalproject2.R;

import java.text.DecimalFormat;

public class PaymentActivity extends AppCompatActivity {

    private TextView tvTotalAmount;
    private Button btnCompletePayment;
    private ImageButton btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        initViews();
        setupClickListeners();
        displayPaymentSummary();
    }

    private void initViews() {
        tvTotalAmount = findViewById(R.id.tv_total_amount);
        btnCompletePayment = findViewById(R.id.btn_complete_payment);
        btnBack = findViewById(R.id.btn_back);
    }

    private void setupClickListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnCompletePayment.setOnClickListener(v -> {
            // Show payment success message
            Toast.makeText(this, "Payment successful!", Toast.LENGTH_SHORT).show();

            // Navigate back to HomeActivity and clear the back stack
            Intent intent = new Intent(PaymentActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void displayPaymentSummary() {
        double totalAmount = getIntent().getDoubleExtra("total_amount", 0);
        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        tvTotalAmount.setText("$" + decimalFormat.format(totalAmount));
    }
}