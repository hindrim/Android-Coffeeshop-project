package com.example.finalproject2.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject2.R;
import com.example.finalproject2.adapters.OrderHistoryAdapter;
import com.example.finalproject2.models.CartItem;
import com.example.finalproject2.models.Order;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderHistoryActivity extends AppCompatActivity implements OrderHistoryAdapter.OnOrderClickListener {

    private RecyclerView rvOrders;
    private LinearLayout llEmptyOrders;
    private ImageButton btnBack;

    private OrderHistoryAdapter orderAdapter;
    private List<Order> orders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        initViews();
        loadOrderHistory();
        setupRecyclerView();
        setupClickListeners();
    }

    private void initViews() {
        rvOrders = findViewById(R.id.rv_orders);
        llEmptyOrders = findViewById(R.id.ll_empty_orders);
        btnBack = findViewById(R.id.btn_back);
    }

    private void loadOrderHistory() {
        orders = new ArrayList<>();

        // Sample data - In real app, load from SharedPreferences or Database
        createSampleOrders();

        // In a real app, you would load from database:
        // orders = DatabaseHelper.getInstance().getAllOrders();
    }

    private void createSampleOrders() {
        // Sample Order 1
        List<CartItem> items1 = new ArrayList<>();
        items1.add(new CartItem(1, "Cappuccino", 4.50, 2, "", "Medium"));
        items1.add(new CartItem(2, "Croissant", 3.00, 1, "", "Regular"));
        Order order1 = new Order("ORD001", items1, 12.00, new Date(System.currentTimeMillis() - 86400000), "Completed", "John Doe");
        orders.add(order1);

        // Sample Order 2
        List<CartItem> items2 = new ArrayList<>();
        items2.add(new CartItem(3, "Latte", 5.00, 1, "", "Large"));
        items2.add(new CartItem(4, "Americano", 3.50, 2, "", "Medium"));
        Order order2 = new Order("ORD002", items2, 12.00, new Date(System.currentTimeMillis() - 172800000), "Completed", "John Doe");
        orders.add(order2);

        // Sample Order 3
        List<CartItem> items3 = new ArrayList<>();
        items3.add(new CartItem(5, "Espresso", 2.50, 3, "", "Small"));
        Order order3 = new Order("ORD003", items3, 7.50, new Date(System.currentTimeMillis() - 259200000), "Pending", "John Doe");
        orders.add(order3);
    }

    private void setupRecyclerView() {
        orderAdapter = new OrderHistoryAdapter(this, orders);
        orderAdapter.setOnOrderClickListener(this);
        rvOrders.setLayoutManager(new LinearLayoutManager(this));
        rvOrders.setAdapter(orderAdapter);

        updateEmptyState();
    }

    private void setupClickListeners() {
        btnBack.setOnClickListener(v -> finish());
    }

    private void updateEmptyState() {
        if (orders.isEmpty()) {
            llEmptyOrders.setVisibility(View.VISIBLE);
            rvOrders.setVisibility(View.GONE);
        } else {
            llEmptyOrders.setVisibility(View.GONE);
            rvOrders.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onReorderClick(Order order) {
        // In a real app, you would add these items back to the cart
        // For now, we'll just show a message
        Toast.makeText(this, "Items added to cart from Order #" + order.getOrderId(), Toast.LENGTH_SHORT).show();

        // Example implementation:
        // CartManager.getInstance().addItemsToCart(order.getItems());
        // finish(); // Go back to previous screen
    }
}