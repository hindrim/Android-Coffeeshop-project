package com.example.finalproject2.models;

public class CartItem {
    private int coffeeId;
    private String productName;
    private double price;
    private int quantity;
    private String imageResource;
    private String size;

    public CartItem() {}

    public CartItem(int coffeeId, String productName, double price, int quantity, String imageUrl, String size) {
        this.coffeeId = coffeeId;
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
        this.imageResource = imageResource;
        this.size = size;
    }

    // Getters and Setters
    public int getCoffeeId() { return coffeeId; }
    public void setCoffeeId(int coffeeId) { this.coffeeId = coffeeId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getImageResource() { return imageResource; }
    public void setImageResource(String imageResource) { this.imageResource = imageResource; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public double getTotalPrice() {
        return price * quantity;
    }
}