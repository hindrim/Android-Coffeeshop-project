package com.example.finalproject2.adapters;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.finalproject2.R;
import com.example.finalproject2.models.Coffee;

import java.util.List;
public class CoffeeAdapter extends RecyclerView.Adapter<CoffeeAdapter.CoffeeViewHolder> {
    private List<Coffee> coffeeList;
    private OnCoffeeClickListener listener;

    public interface OnCoffeeClickListener {
        void onCoffeeClick(Coffee coffee);
    }

    public CoffeeAdapter(List<Coffee> coffeeList, OnCoffeeClickListener listener) {
        this.coffeeList = coffeeList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CoffeeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_coffee, parent, false);
        return new CoffeeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CoffeeViewHolder holder, int position) {
        holder.bind(coffeeList.get(position));
    }

    @Override
    public int getItemCount() {
        return coffeeList.size();
    }

    // ✅ Inner class - has access to coffeeList and listener
    class CoffeeViewHolder extends RecyclerView.ViewHolder {
        private ImageView imageView;
        private TextView nameText, descriptionText, priceText, quantityText;
        private android.widget.Button btnAdd, btnRemove;

        public CoffeeViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.coffeeImage);
            nameText = itemView.findViewById(R.id.coffeeName);
            descriptionText = itemView.findViewById(R.id.coffeeDescription);
            priceText = itemView.findViewById(R.id.coffeePrice);
            quantityText = itemView.findViewById(R.id.tvQuantity);
            btnAdd = itemView.findViewById(R.id.btnAdd);
            btnRemove = itemView.findViewById(R.id.btnRemove);

            itemView.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onCoffeeClick(coffeeList.get(position));
                }

            });
        }

        public void bind(Coffee coffee) {
            imageView.setImageResource(coffee.getImageResource());
            nameText.setText(coffee.getName());
            descriptionText.setText(coffee.getDescription());
            priceText.setText(String.format("$%.2f", coffee.getPrice()));
            quantityText.setText(String.valueOf(coffee.getQuantity()));

            btnAdd.setOnClickListener(v -> {
                int qty = coffee.getQuantity() + 1;
                coffee.setQuantity(qty);
                quantityText.setText(String.valueOf(qty));
            });

            btnRemove.setOnClickListener(v -> {
                int qty = coffee.getQuantity();
                if (qty > 0) {
                    coffee.setQuantity(qty - 1);
                    quantityText.setText(String.valueOf(qty - 1));
                }
            });
        }
    }
}
