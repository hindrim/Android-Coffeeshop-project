package com.example.finalproject2.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject2.R;
import com.example.finalproject2.adapters.CartAdapter;
import com.example.finalproject2.models.CartItem;
import com.example.finalproject2.models.Order;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class CartActivity extends AppCompatActivity implements CartAdapter.OnCartItemClickListener {

    private RecyclerView rvCartItems;
    private TextView tvTotalItems, tvTotalAmount;
    private Button btnCheckout;
    private LinearLayout llEmptyCart, llCartSummary;
    private ImageButton btnBack, btnClearCart;

    private CartAdapter cartAdapter;
    private List<CartItem> cartItems;
    private DecimalFormat decimalFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        initViews();
        initData();
        setupRecyclerView();
        setupClickListeners();
        updateCartSummary();
    }

    private void initViews() {
        rvCartItems = findViewById(R.id.rv_cart_items);
        tvTotalItems = findViewById(R.id.tv_total_items);
        tvTotalAmount = findViewById(R.id.tv_total_amount);
        btnCheckout = findViewById(R.id.btn_checkout);
        llEmptyCart = findViewById(R.id.ll_empty_cart);
        llCartSummary = findViewById(R.id.ll_cart_summary);
        btnBack = findViewById(R.id.btn_back);
        btnClearCart = findViewById(R.id.btn_clear_cart);

        decimalFormat = new DecimalFormat("#0.00");
    }

    private void initData() {
        cartItems = new ArrayList<>();
        // Sample data
        cartItems.add(new CartItem(1, "Cappuccino", 4.50, 0, "", "Medium"));
        cartItems.add(new CartItem(2, "Latte", 5.00, 0, "", "Large"));
        cartItems.add(new CartItem(3, "Americano", 3.50, 0, "", "Small"));
        cartItems.add(new CartItem(4, "Espresso", 3.00, 0, "", "Medium"));
        cartItems.add(new CartItem(5, "Mocha", 5.50, 0, "", "Large"));
    }

    private void setupRecyclerView() {
        cartAdapter = new CartAdapter(this, cartItems);
        cartAdapter.setOnCartItemClickListener(this);
        rvCartItems.setLayoutManager(new LinearLayoutManager(this));
        rvCartItems.setAdapter(cartAdapter);
    }

    private void setupClickListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnClearCart.setOnClickListener(v -> showClearCartDialog());

        btnCheckout.setOnClickListener(v -> proceedToCheckout());
    }

    private void showClearCartDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Clear Cart")
                .setMessage("Are you sure you want to remove all items from your cart?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    cartItems.clear();
                    cartAdapter.notifyDataSetChanged();
                    updateCartSummary();
                    Toast.makeText(this, "Cart cleared", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void proceedToCheckout() {
        if (cartItems.isEmpty()) {
            Toast.makeText(this, "Your cart is empty", Toast.LENGTH_SHORT).show();
            return;
        }

        // Navigate to CheckoutActivity
        Intent intent = new Intent(CartActivity.this, CheckoutActivity.class);
        intent.putExtra("total_amount", calculateTotalAmount());
        intent.putExtra("total_items", calculateTotalItems());
        startActivity(intent);
    }

    private void updateCartSummary() {
        if (cartItems.isEmpty()) {
            llEmptyCart.setVisibility(View.VISIBLE);
            llCartSummary.setVisibility(View.GONE);
            rvCartItems.setVisibility(View.GONE);
        } else {
            llEmptyCart.setVisibility(View.GONE);
            llCartSummary.setVisibility(View.VISIBLE);
            rvCartItems.setVisibility(View.VISIBLE);

            int totalItems = calculateTotalItems();
            double totalAmount = calculateTotalAmount();

            tvTotalItems.setText(String.valueOf(totalItems));
            tvTotalAmount.setText("$" + decimalFormat.format(totalAmount));
        }
    }

    private int calculateTotalItems() {
        int total = 0;
        for (CartItem item : cartItems) {
            total += item.getQuantity();
        }
        return total;
    }

    private double calculateTotalAmount() {
        double total = 0;
        for (CartItem item : cartItems) {
            total += item.getPrice() * item.getQuantity();
        }
        return total;
    }

    @Override
    public void onIncreaseQuantity(int position) {
        CartItem item = cartItems.get(position);
        item.setQuantity(item.getQuantity() + 1);
        cartAdapter.notifyItemChanged(position);
        updateCartSummary();
    }

    @Override
    public void onDecreaseQuantity(int position) {
        CartItem item = cartItems.get(position);
        if (item.getQuantity() > 1) {
            item.setQuantity(item.getQuantity() - 1);
            cartAdapter.notifyItemChanged(position);
            updateCartSummary();
        } else {
            onRemoveItem(position);
        }
    }

    @Override
    public void onRemoveItem(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Remove Item")
                .setMessage("Are you sure you want to remove this item from your cart?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    cartItems.remove(position);
                    cartAdapter.notifyItemRemoved(position);
                    updateCartSummary();
                    Toast.makeText(this, "Item removed from cart", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("No", null)
                .show();
    }
}