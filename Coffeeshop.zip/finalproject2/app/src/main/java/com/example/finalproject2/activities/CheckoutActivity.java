package com.example.finalproject2.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.finalproject2.R;

import java.text.DecimalFormat;

public class CheckoutActivity extends AppCompatActivity {

    private TextView tvTotalAmount;
    private Button btnProceedToPayment;
    private ImageButton btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        initViews();
        setupClickListeners();
        displayPaymentSummary();
    }

    private void initViews() {
        tvTotalAmount = findViewById(R.id.tv_total_amount);
        btnProceedToPayment = findViewById(R.id.btn_proceed_to_payment);
        btnBack = findViewById(R.id.btn_back);
    }

    private void setupClickListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnProceedToPayment.setOnClickListener(v -> {
            Intent intent = new Intent(CheckoutActivity.this, PaymentActivity.class);
            intent.putExtra("total_amount", getIntent().getDoubleExtra("total_amount", 0));
            startActivity(intent);
        });
    }

    private void displayPaymentSummary() {
        double totalAmount = getIntent().getDoubleExtra("total_amount", 0);
        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        tvTotalAmount.setText("$" + decimalFormat.format(totalAmount));
    }
}