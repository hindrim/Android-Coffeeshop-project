package com.example.finalproject2.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject2.R;
import com.example.finalproject2.models.CartItem;

import java.text.DecimalFormat;
import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private Context context;
    private List<CartItem> cartItems;
    private OnCartItemClickListener listener;
    private DecimalFormat decimalFormat;

    public interface OnCartItemClickListener {
        void onIncreaseQuantity(int position);
        void onDecreaseQuantity(int position);
        void onRemoveItem(int position);
    }

    public CartAdapter(Context context, List<CartItem> cartItems) {
        this.context = context;
        this.cartItems = cartItems;
        this.decimalFormat = new DecimalFormat("#0.00");
    }

    public void setOnCartItemClickListener(OnCartItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartItems.get(position);

        holder.tvProductName.setText(item.getProductName());
        holder.tvProductSize.setText(item.getSize());
        holder.tvProductPrice.setText("$" + decimalFormat.format(item.getPrice()));
        holder.tvQuantity.setText(String.valueOf(item.getQuantity()));

        // Load image based on coffee name
        int imageResId = getImageResourceForCoffee(item.getProductName());
        if (imageResId != 0) {
            holder.ivProductImage.setImageResource(imageResId);
        } else {
            // Set default image if no specific image found
            holder.ivProductImage.setImageResource(R.drawable.default_coffee);
        }
    }

    private int getImageResourceForCoffee(String coffeeName) {
        // Convert coffee name to lowercase and replace spaces with underscores
        String imageName = coffeeName.toLowerCase().replace(" ", "_");

        // Get the resource ID dynamically
        return context.getResources().getIdentifier(
                imageName,
                "drawable",
                context.getPackageName()
        );
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    public class CartViewHolder extends RecyclerView.ViewHolder {
        ImageView ivProductImage;
        TextView tvProductName, tvProductSize, tvProductPrice, tvQuantity;
        ImageButton btnIncrease, btnDecrease, btnRemoveItem;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);

            ivProductImage = itemView.findViewById(R.id.iv_product_image);
            tvProductName = itemView.findViewById(R.id.tv_product_name);
            tvProductSize = itemView.findViewById(R.id.tv_product_size);
            tvProductPrice = itemView.findViewById(R.id.tv_product_price);
            tvQuantity = itemView.findViewById(R.id.tv_quantity);
            btnIncrease = itemView.findViewById(R.id.btn_increase);
            btnDecrease = itemView.findViewById(R.id.btn_decrease);
            btnRemoveItem = itemView.findViewById(R.id.btn_remove_item);

            btnIncrease.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onIncreaseQuantity(position);
                }

            });

            btnDecrease.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onIncreaseQuantity(position);
                }

            });

            btnRemoveItem.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onIncreaseQuantity(position);
                }

            });
        }
    }
}