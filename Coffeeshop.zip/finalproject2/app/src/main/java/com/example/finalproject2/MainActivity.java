package com.example.finalproject2;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.finalproject2.activities.CartActivity;
import com.example.finalproject2.activities.OrderHistoryActivity;
import com.example.finalproject2.adapters.CoffeeAdapter;
import com.example.finalproject2.models.CartItem;
import com.example.finalproject2.models.Coffee;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements CoffeeAdapter.OnCoffeeClickListener {

    private RecyclerView recyclerView;
    private CoffeeAdapter coffeeAdapter;
    private List<Coffee> coffeeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupRecyclerView();
        loadCoffeeData();
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recyclerView);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("BrewMaster Coffee");
        }
    }

    private void setupRecyclerView() {
        coffeeList = new ArrayList<>();
        coffeeAdapter = new CoffeeAdapter(coffeeList, this);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(coffeeAdapter);
    }

    private void loadCoffeeData() {
        // Sample coffee data - replace with your actual data source
        coffeeList.add(new Coffee(1, "Cappuccino", "Classic cappuccino with foam", 4.50, R.drawable.cappuccino));
        coffeeList.add(new Coffee(2, "Latte", "Smooth latte with milk", 5.00, R.drawable.latte));
        coffeeList.add(new Coffee(3, "Americano", "Strong black coffee", 3.50, R.drawable.americano));
        coffeeList.add(new Coffee(4, "Espresso", "Concentrated coffee shot", 3.00, R.drawable.espresso));
        coffeeList.add(new Coffee(5, "Mocha", "Chocolate coffee delight", 5.50, R.drawable.mocha));
        coffeeList.add(new Coffee(5, "Macchiato", "Chocolate coffee delight", 32.00, R.drawable.macchiato));

        coffeeList.add(new Coffee(5, "CupCake", "Our CupCake is the best", 10.50, R.drawable.cupcake));
        coffeeList.add(new Coffee(5, "Frappuccino", "Chocolate coffee delight", 15.50, R.drawable.frappuccino));

        coffeeAdapter.notifyDataSetChanged();
    }

    @Override
    public void onCoffeeClick(Coffee coffee) {
        // Handle coffee item click
        Toast.makeText(this, "Added " + coffee.getName() + " to cart", Toast.LENGTH_SHORT).show();

        // Create a CartItem from the Coffee object
        CartItem cartItem = new CartItem(
                coffee.getId(),
                coffee.getName(),
                coffee.getPrice(),
                1, // Default quantity
                String.valueOf(coffee.getImageResource()), // Convert image resource to String
                "Medium" // Default size
        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_cart) {
            startActivity(new Intent(this, CartActivity.class));
            return true;
        } else if (id == R.id.action_add_row) {
            startActivity(new Intent(this, OrderHistoryActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}